# My_blog/routes/main.py
from flask import (render_template, Blueprint, request, redirect, url_for,
                   flash, current_app, g, session, jsonify, send_from_directory)
from werkzeug.utils import secure_filename
from ..models import db, Post, Comment, Category, Tag, User
from flask_login import login_required, current_user
import datetime
import os

bp = Blueprint('main', __name__)


@bp.before_app_request
def before_request():
    g.current_year = datetime.datetime.now(datetime.timezone.utc).year
    g.current_theme_for_background_fade = session.get('visual_theme', 'light')
    g.is_admin = current_user.is_authenticated and getattr(current_user, 'is_admin', False)


@bp.route('/favicon.ico')
def favicon():
    try:
        return send_from_directory(os.path.join(current_app.root_path, 'static'),
                                   'favicon.ico', mimetype='image/vnd.microsoft.icon')
    except FileNotFoundError:
        return '', 204


@bp.route('/set-visual-theme/<theme_name>')
def set_visual_theme(theme_name):
    valid_themes = ['light', 'dark', 'blue', 'green', 'yuan']
    if theme_name in valid_themes: session['visual_theme'] = theme_name
    return redirect(request.referrer or url_for('main.index'))


@bp.route('/')
@bp.route('/index')
def index():
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('POSTS_PER_PAGE', 5)
    pagination = Post.query.order_by(Post.timestamp.desc()).paginate(page=page, per_page=per_page, error_out=False)
    posts = pagination.items
    return render_template('index.html', title='首页', posts=posts, pagination=pagination)


def allowed_file(filename):
    return '.' in filename and \
        filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS']


@bp.route('/upload', methods=['POST'])
@login_required
def upload_file():
    if 'file' not in request.files: return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '': return jsonify({'error': 'No selected file'}), 400
    if 'ALLOWED_EXTENSIONS' not in current_app.config: return jsonify({'error': 'Server config error.'}), 500
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        upload_folder = current_app.config['UPLOADED_MEDIA_DEST']
        os.makedirs(upload_folder, exist_ok=True)
        filepath = os.path.join(upload_folder, filename)
        base, ext = os.path.splitext(filepath)
        counter = 1
        while os.path.exists(filepath):
            filepath = f"{base}_{counter}{ext}";
            filename = f"{os.path.basename(base)}_{counter}{ext}";
            counter += 1
        try:
            file.save(filepath);
            file_url = url_for('static', filename=f'uploads/{filename}', _external=False);
            return jsonify({'url': file_url})
        except Exception as e:
            current_app.logger.error(f"File save error: {e}");
            return jsonify({'error': f'Could not save file: {str(e)}'}), 500
    else:
        return jsonify({'error': 'File type not allowed'}), 400


@bp.route('/post/<slug>')
def post(slug):
    post_instance = Post.query.filter_by(slug=slug).first_or_404()
    page = request.args.get('page', 1, type=int)
    comments_per_page = current_app.config.get('COMMENTS_PER_PAGE', 10)
    comments_pagination = post_instance.comments.filter(Comment.parent_id == None).order_by(
        Comment.timestamp.asc()).paginate(page=page, per_page=comments_per_page, error_out=False)
    comments = comments_pagination.items
    return render_template('post.html', title=post_instance.title, post=post_instance, comments=comments,
                           pagination=comments_pagination)


@bp.route('/create', methods=['GET', 'POST'])
@login_required
def create_post():
    if request.method == 'POST':
        title = request.form.get('title');
        body = request.form.get('body')
        category_name = request.form.get('category');
        tag_names_str = request.form.get('tags', '')
        if not title or not body:
            flash('标题和内容不能为空！', 'danger')
            return render_template('create_post.html', title='创建新文章', title_data=title, body_data=body,
                                   category_data=category_name, tags_data=tag_names_str)
        category = None
        if category_name and category_name.strip():
            category_name = category_name.strip()
            category = Category.query.filter_by(name=category_name).first()
            if not category: category = Category(name=category_name); db.session.add(category)
        new_post = Post(title=title, body=body, author=current_user, category=category);
        new_post.generate_slug()
        if tag_names_str:
            tag_names = [name.strip() for name in tag_names_str.split(',') if name.strip()]
            for tag_name in tag_names:
                tag = Tag.query.filter_by(name=tag_name).first()
                if not tag: tag = Tag(name=tag_name); db.session.add(tag)
                if tag not in new_post.tags: new_post.tags.append(tag)
        db.session.add(new_post)
        try:
            db.session.commit()
            flash('文章创建成功！', 'success')
            # ************ 关键修改点: 重定向到首页 ************
            return redirect(url_for('main.post', slug=new_post.slug))
            # *******************************************************
        except Exception as e:
            db.session.rollback()
            current_app.logger.error(f"创建文章失败: {e}")  # <-- 检查终端日志！
            flash(f'创建文章失败，请检查日志或联系管理员。', 'danger')
            return render_template('create_post.html', title='创建新文章', title_data=title, body_data=body,
                                   category_data=category_name, tags_data=tag_names_str)

    return render_template('create_post.html', title='创建新文章')


# ... (edit_post, delete_post, add_comment, search 保持不变) ...
@bp.route('/edit/<slug>', methods=['GET', 'POST'])
@login_required
def edit_post(slug):
    post_to_edit = Post.query.filter_by(slug=slug).first_or_404()
    if post_to_edit.author != current_user and not g.is_admin: flash('您没有权限编辑此文章。',
                                                                     'danger'); return redirect(url_for('main.index'))
    if request.method == 'POST':
        post_to_edit.title = request.form.get('title');
        post_to_edit.body = request.form.get('body')
        category_name = request.form.get('category');
        tag_names_str = request.form.get('tags', '')
        category = None
        if category_name and category_name.strip():
            category = Category.query.filter_by(name=category_name.strip()).first()
            if not category: category = Category(name=category_name.strip()); db.session.add(category)
        post_to_edit.category = category;
        post_to_edit.tags = []
        if tag_names_str:
            tag_names = [name.strip() for name in tag_names_str.split(',') if name.strip()]
            for tag_name in tag_names:
                tag = Tag.query.filter_by(name=tag_name).first()
                if not tag: tag = Tag(name=tag_name); db.session.add(tag)
                post_to_edit.tags.append(tag)
        post_to_edit.generate_slug(post_to_edit.title)
        try:
            db.session.commit(); flash('文章更新成功！', 'success'); return redirect(
                url_for('main.post', slug=post_to_edit.slug))
        except Exception as e:
            db.session.rollback(); flash(f'更新文章失败: {str(e)}', 'danger')
    existing_tags = ', '.join([tag.name for tag in post_to_edit.tags])
    return render_template('edit_post.html', title='编辑文章', post=post_to_edit, existing_tags=existing_tags)


@bp.route('/post/<slug>/delete', methods=['POST'])
@login_required
def delete_post(slug):
    post_to_delete = Post.query.filter_by(slug=slug).first_or_404()
    if post_to_delete.author != current_user and not g.is_admin: flash('您没有权限删除此文章。',
                                                                       'danger'); return redirect(url_for('main.index'))
    db.session.delete(post_to_delete);
    db.session.commit();
    flash('文章删除成功。', 'success')
    return redirect(url_for('main.index'))


@bp.route('/post/<slug>/comment', methods=['POST'])
@login_required
def add_comment(slug):
    post_instance = Post.query.filter_by(slug=slug).first_or_404()
    body = request.form.get('body', '').strip();
    parent_id_str = request.form.get('parent_id')
    if not body: flash('评论内容不能为空。', 'danger'); return redirect(
        url_for('main.post', slug=slug, _anchor='comment-form'))
    parent_comment = None
    if parent_id_str and parent_id_str.isdigit():
        parent_id = int(parent_id_str);
        parent_comment = Comment.query.get(parent_id)
        if parent_comment and parent_comment.post_id != post_instance.id:
            flash('无效的父评论。', 'danger'); return redirect(url_for('main.post', slug=slug))
        elif not parent_comment:
            flash('指定的父评论不存在。', 'warning'); parent_id_str = None
    comment = Comment(body=body, author=current_user, post=post_instance, parent=parent_comment);
    db.session.add(comment)
    try:
        db.session.commit(); flash('评论已发布。', 'success'); return redirect(
            url_for('main.post', slug=slug, _anchor=f'comment-{comment.id}'))
    except Exception as e:
        db.session.rollback(); flash(f'发布评论失败。错误: {str(e)}', 'danger'); return redirect(
            url_for('main.post', slug=slug, _anchor='comment-form'))


@bp.route('/search')
def search():
    query = request.args.get('q', '').strip()
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('POSTS_PER_PAGE', 5)
    pagination = None
    if query:
        # 简单 LIKE 搜索示例
        search_term = f"%{query}%"
        pagination = Post.query.filter(db.or_(Post.title.ilike(search_term), Post.body.ilike(search_term))).order_by(
            Post.timestamp.desc()).paginate(page=page, per_page=per_page, error_out=False)
    else:
        flash('请输入搜索关键词。', 'info')
        pagination = Post.query.filter_by(id=-1).paginate(page=1, per_page=per_page, error_out=False)
    posts = pagination.items if pagination else []
    return render_template('search.html', title=f"搜索: {query}", query=query, posts=posts, pagination=pagination)