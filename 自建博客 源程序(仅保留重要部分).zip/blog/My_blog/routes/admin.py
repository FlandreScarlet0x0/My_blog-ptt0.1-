# My_blog/routes/admin.py
from flask import Blueprint, render_template, current_app, request, flash, redirect, url_for  # 添加导入
from flask_login import login_required
from ..extensions import admin_required, db  # 确保 db 也导入
from ..models import User, Post  # 从正确的相对路径导入

bp = Blueprint('admin', __name__, url_prefix='/admin')


@bp.route('/')
@login_required
@admin_required
def index():
    # 确保这个模板在 templates/admin/index.html
    return render_template('admin/index.html', title="管理后台")


@bp.route('/users')
@login_required
@admin_required
def manage_users():
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('POSTS_PER_PAGE', 10)
    pagination = User.query.order_by(User.member_since.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    users = pagination.items
    # 确保这个模板在 templates/admin/users.html
    return render_template('admin/users.html', title="用户管理", users=users, pagination=pagination)


@bp.route('/posts')
@login_required
@admin_required
def manage_posts():
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('POSTS_PER_PAGE', 10)
    pagination = Post.query.order_by(Post.timestamp.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    posts = pagination.items
    # 确保这个模板在 templates/admin/posts.html
    return render_template('admin/posts.html', title="文章管理", posts=posts, pagination=pagination)


# 管理员删除文章 (补充之前 main.py 中的 delete_post 功能，这里可以专门为管理员设计)
@bp.route('/post/<int:post_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_post_admin(post_id):
    post_to_delete = Post.query.get_or_404(post_id)
    try:
        db.session.delete(post_to_delete)
        db.session.commit()
        flash(f'文章 "{post_to_delete.title}" 已被管理员删除。', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'删除文章失败。错误: {str(e)}', 'danger')
    return redirect(url_for('admin.manage_posts'))


# 管理员编辑文章的链接可以指向 main.edit_post，因为它已经有权限检查
# 如果需要管理员专属编辑页面，则需要另外创建路由和模板

# 管理员用户操作 (例如：提升为管理员，禁用用户等)
@bp.route('/user/<int:user_id>/toggle-admin', methods=['POST'])
@login_required
@admin_required
def toggle_admin_status(user_id):
    user_to_modify = User.query.get_or_404(user_id)
    if user_to_modify == current_user:
        flash('不能修改自己的管理员状态。', 'warning')
        return redirect(url_for('admin.manage_users'))

    user_to_modify.is_admin = not user_to_modify.is_admin
    try:
        db.session.commit()
        status = "管理员" if user_to_modify.is_admin else "普通用户"
        flash(f'用户 {user_to_modify.username} 的状态已更新为 {status}。', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'更新用户状态失败。错误: {str(e)}', 'danger')
    return redirect(url_for('admin.manage_users'))