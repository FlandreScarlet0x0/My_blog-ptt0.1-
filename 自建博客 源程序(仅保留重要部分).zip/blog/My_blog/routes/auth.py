# My_blog/routes/auth.py
from flask import render_template, Blueprint, request, redirect, url_for, flash, current_app
from urllib.parse import urlparse
from flask_login import login_user, logout_user, current_user, login_required
from ..models import db, User, Post # <-- 使用相对导入
from ..extensions import login_manager # <-- 使用相对导入

bp = Blueprint('auth', __name__, url_prefix='/auth')

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ... (login, logout, register, edit_profile, profile 路由保持不变，但要确保模板路径正确) ...
@bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated: return redirect(url_for('main.index'))
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        remember = request.form.get('remember_me') is not None
        user = User.query.filter_by(username=username).first()
        if user is None or not user.check_password(password):
            flash('无效的用户名或密码。', 'danger')
            return redirect(url_for('auth.login'))
        login_user(user, remember=remember)
        next_page = request.args.get('next')
        if not next_page or urlparse(next_page).netloc != '':
            next_page = url_for('main.index')
        return redirect(next_page)
    return render_template('login.html', title='登录') # <-- 确保模板在 templates/ 目录下

@bp.route('/logout')
def logout():
    logout_user()
    return redirect(url_for('main.index'))

@bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated: return redirect(url_for('main.index'))
    if request.method == 'POST':
        username = request.form.get('username')
        email = request.form.get('email')
        password = request.form.get('password')
        password2 = request.form.get('password2')
        if password != password2: flash('两次输入的密码不匹配！', 'danger'); return redirect(url_for('auth.register'))
        if User.query.filter_by(username=username).first(): flash('用户名已被占用。', 'warning'); return redirect(url_for('auth.register'))
        if User.query.filter_by(email=email).first(): flash('该邮箱地址已被注册。', 'warning'); return redirect(url_for('auth.register'))
        user = User(username=username, email=email); user.set_password(password)
        db.session.add(user); db.session.commit()
        flash('恭喜您，注册成功！请登录。', 'success')
        return redirect(url_for('auth.login'))
    return render_template('register.html', title='注册') # <-- 确保模板在 templates/ 目录下

@bp.route('/edit_profile', methods=['GET', 'POST'])
@login_required
def edit_profile():
    if request.method == 'POST':
        new_username = request.form.get('username', current_user.username).strip()
        new_about_me = request.form.get('about_me', '').strip()
        if new_username and new_username != current_user.username:
            if User.query.filter(User.username == new_username, User.id != current_user.id).first():
                flash('此用户名已被占用。', 'warning')
                return render_template('edit_profile.html', title='编辑资料', user=current_user)
            current_user.username = new_username
        current_user.about_me = new_about_me
        db.session.commit(); flash('资料已更新。', 'success')
        return redirect(url_for('auth.profile', username=current_user.username))
    return render_template('edit_profile.html', title='编辑资料', user=current_user) # <-- 确保模板在 templates/ 目录下

@bp.route('/profile/<username>')
def profile(username): # 不需要 login_required 即可公开查看
    user = User.query.filter_by(username=username).first_or_404()
    page = request.args.get('page', 1, type=int)
    per_page = current_app.config.get('POSTS_PER_PAGE', 5)
    pagination = Post.query.filter_by(author=user).order_by(Post.timestamp.desc()).paginate(
        page=page, per_page=per_page, error_out=False
    )
    posts = pagination.items
    return render_template('profile.html', title=f"{user.username}的资料", user=user, posts=posts, pagination=pagination) # <-- 确保模板在 templates/ 目录下