// static/js/theme.js

(function() {
    const htmlElement = document.documentElement;
    const themeToggleButton = document.getElementById('themeToggle');
    const sunIconClass = 'fas fa-sun';
    const moonIconClass = 'fas fa-moon';

    function applyTheme(theme) {
        document.documentElement.style.transition = 'background-color 0.3s ease, color 0.3s ease';
        htmlElement.setAttribute('data-theme', theme);

        if (themeToggleButton) {
            if (theme === 'dark') {
                themeToggleButton.innerHTML = `<i class="${sunIconClass}"></i>`;
                themeToggleButton.setAttribute('title', '切换到浅色模式');
            } else {
                themeToggleButton.innerHTML = `<i class="${moonIconClass}"></i>`;
                themeToggleButton.setAttribute('title', '切换到深色模式');
            }
        }

        try {
            localStorage.setItem('theme', theme);
        } catch (e) {
            console.warn("LocalStorage 不可用。主题偏好将不会被保存。");
        }
    }

    // 初始主题设置
    const currentInitialTheme = htmlElement.getAttribute('data-theme') || 'light';
    if (themeToggleButton) {
        if (currentInitialTheme === 'dark') {
            themeToggleButton.innerHTML = `<i class="${sunIconClass}"></i>`;
            themeToggleButton.setAttribute('title', '切换到浅色模式');
        } else {
            themeToggleButton.innerHTML = `<i class="${moonIconClass}"></i>`;
            themeToggleButton.setAttribute('title', '切换到深色模式');
        }
    }

    // 主题切换按钮事件
    if (themeToggleButton) {
        themeToggleButton.addEventListener('click', () => {
            const currentTheme = htmlElement.getAttribute('data-theme') || 'light';
            const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
            applyTheme(newTheme);
        });
    }

    // 系统主题变化监听
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        try {
            if (!localStorage.getItem('theme')) {
                applyTheme(e.matches ? 'dark' : 'light');
            }
        } catch (err) {}
    });
})();