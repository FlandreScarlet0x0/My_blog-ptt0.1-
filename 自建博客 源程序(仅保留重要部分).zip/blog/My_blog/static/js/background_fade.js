// static/js/background_fade.js

const themeImageUrls = {
    light: "",
    dark: "url('https://s21.ax1x.com/2025/05/02/pEbG0XD.jpg')",
    blue: "url('https://s21.ax1x.com/2025/05/02/pEbGG79.jpg')",
    green: "url('https://s21.ax1x.com/2025/05/02/pEb1xnH.jpg')",
    yuan: "url('https://s21.ax1x.com/2025/05/02/pEbGlXF.jpg')"
};

const themeMusicUrls = {
    light: "",
    dark: "https://music.163.com/outchain/player?type=2&id=2034454236&auto=1&height=66",
    blue: "https://music.163.com/outchain/player?type=2&id=1961353401&auto=1&height=66",
    green: "https://music.163.com/outchain/player?type=2&id=1303019326&auto=0&height=66",
    yuan: "https://music.163.com/outchain/player?type=2&id=29732992&auto=1&height=66"
};

// --- 预加载图片 ---
function preloadBackgroundImages(urls) {
    Object.values(urls).forEach(url => {
        if (url && url.startsWith('url(')) {
            const imgUrl = url.match(/url\(['"]?(.*?)['"]?\)/)[1];
            if (imgUrl !== 'none' && !imgUrl.startsWith('/static/images/none')) { // 避免加载 'none'
                const img = new Image();
                img.src = imgUrl;
            }
        }
    });
}

function applyVisualBackgroundTheme() {
    const mainContent = document.getElementById('ajax-content-container');
    if (!mainContent) return;
    mainContent.classList.add('main-content');

    const currentTheme = mainContent.dataset.currentTheme || 'light';
    const previousTheme = sessionStorage.getItem('previous_theme_for_bg');
    const beforeImage = themeImageUrls[previousTheme] || 'none';
    const afterImage = themeImageUrls[currentTheme] || 'none';

    mainContent.style.setProperty('--before-bg-image', beforeImage);
    mainContent.style.setProperty('--after-bg-image', afterImage);
    mainContent.classList.remove('js-bg-before-active', 'js-bg-after-active');

    if (previousTheme && previousTheme !== currentTheme && beforeImage !== 'none' && afterImage !== 'none') {
        mainContent.classList.add('js-bg-before-active');
        setTimeout(() => {
            mainContent.classList.add('js-bg-after-active');
            mainContent.classList.remove('js-bg-before-active');
            mainContent.style.setProperty('--before-bg-image', afterImage);
        }, 600);
    } else {
        mainContent.classList.add('js-bg-after-active');
        mainContent.style.setProperty('--before-bg-image', afterImage);
    }

    handleThemeMusic(currentTheme);
    sessionStorage.setItem('previous_theme_for_bg', currentTheme);
}

function handleThemeMusic(theme) {
    const musicPlayer = document.getElementById('theme-music-player');
    if (!musicPlayer) return;

    const musicUrl = themeMusicUrls[theme] || "";
    const currentSrc = musicPlayer.getAttribute('src');

    // ************ 关键修改点 ************
    if (musicUrl !== currentSrc) {
        console.log(`音乐状态改变: ${currentSrc || '无'} -> ${musicUrl || '无'}`);
        musicPlayer.src = musicUrl;
    }
    // 根据是否有 URL 来决定显示或隐藏
    musicPlayer.style.display = musicUrl ? 'block' : 'none';
    // **************************************
}

// --- 初始化函数 ---
function initializePageElements() {
    const mainContent = document.getElementById('ajax-content-container');
    if (mainContent) {
        mainContent.classList.add('main-content');
        applyVisualBackgroundTheme(); // 应用背景
        // 初始加载时，也让 handleThemeMusic 检查一次
        handleThemeMusic(mainContent.dataset.currentTheme || 'light');
    }
}

// --- 事件监听 ---
document.addEventListener('DOMContentLoaded', () => {
    preloadBackgroundImages(themeImageUrls);
    initializePageElements();

    window.addEventListener('beforeunload', () => {
        const mainContent = document.getElementById('ajax-content-container');
        if (mainContent) {
             sessionStorage.setItem('previous_theme_for_bg', mainContent.dataset.currentTheme || 'light');
        }
    });
});

// --- 暴露给 navigation.js ---
window.reapplyVisualBackgroundTheme = initializePageElements; // AJAX 加载后调用这个