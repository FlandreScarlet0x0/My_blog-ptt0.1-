// static/js/navigation.js
document.addEventListener('DOMContentLoaded', () => {
    const ajaxContainerId = 'ajax-content-container';

    function loadPage(url, pushState = true) {
        console.log(`AJAX Loading: ${url}`);
        fetch(url, {
            headers: { 'X-Requested-With': 'XMLHttpRequest' }
        })
        .then(response => {
            if (!response.ok) { window.location.href = url; return Promise.reject(new Error('Network response was not ok.')); }
            return response.text();
        })
        .then(html => {
            const parser = new DOMParser();
            const doc = parser.parseFromString(html, 'text/html');

            const newContentContainer = doc.getElementById(ajaxContainerId);
            const newContent = newContentContainer ? newContentContainer.innerHTML : null;
            const newTitle = doc.title;

            if (!newContent) { console.error("Could not find AJAX container in fetched content."); window.location.href = url; return; }

            document.getElementById(ajaxContainerId).innerHTML = newContent;
            document.title = newTitle;

            if (pushState) { history.pushState({ path: url }, '', url); }

            const mainContent = document.getElementById(ajaxContainerId);
            if (newContentContainer && mainContent) {
                mainContent.dataset.currentTheme = newContentContainer.dataset.currentTheme || 'light';
            }

            if (window.reapplyVisualBackgroundTheme) { window.reapplyVisualBackgroundTheme(); }

            // 重新绑定链接，并重新初始化可能需要的 JS (如 EasyMDE)
            attachLinkListeners();
            // 如果新页面是 create_post 或 edit_post，需要重新初始化 EasyMDE
            // 这可以通过检查新内容中是否有 #body 元素来实现
            if (document.getElementById('body')) {
                // 这里需要调用一个函数来重新初始化 EasyMDE。
                // 这可能需要将 create_post.html/edit_post.html 中的 JS 封装成一个可重用的函数。
                // 简单起见，我们暂时不在 AJAX 中处理编辑器页面。
                console.log("Editor page loaded via AJAX - Manual refresh might be needed for full JS functionality.");
            }
            window.scrollTo(0, 0);
        })
        .catch(error => { console.error('AJAX load failed:', error); window.location.href = url; });
    }

    function attachLinkListeners() {
        document.querySelectorAll('a.internal-link').forEach(link => {
            link.removeEventListener('click', handleInternalLinkClick); // 移除旧的
            link.addEventListener('click', handleInternalLinkClick); // 添加新的
        });
    }

    function handleInternalLinkClick(event) {
        const link = event.currentTarget;
        if (link.target === '_blank' || event.ctrlKey || event.metaKey ||
            link.hostname !== window.location.hostname ||
            link.href.includes('/set-visual-theme/') || // 不拦截视觉主题切换
            link.pathname.includes('/logout') || // 不拦截登出
            link.closest('form')) { // 不拦截表单提交中的链接 (虽然通常不用)
            return;
        }
        // 不拦截创建和编辑页面的链接，因为 EasyMDE 初始化复杂
        if (link.pathname.includes('/create') || link.pathname.includes('/edit/')) {
             console.log("Navigating to editor page with full reload.");
             return;
        }
        event.preventDefault();
        loadPage(link.href);
    }

    attachLinkListeners();
    window.addEventListener('popstate', event => {
        if (event.state?.path) { loadPage(event.state.path, false); }
    });
});